
public class AudiTire extends Tire {

	public AudiTire() {
		super("Audi Tire");
	}

}
