
public class MercedesTire extends Tire {

	public MercedesTire() {
		super("Mercedes Tire");
	}

}
