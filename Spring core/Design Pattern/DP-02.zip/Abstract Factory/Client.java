
public class Client {

	public static void main(String[] args) {

		Tire audiT = FactoryGetter.getFactory("audi").makeTire();
		Tire mercT = FactoryGetter.getFactory("mercedes").makeTire();
		System.out.println(audiT.getModel());
		System.out.println(mercT.getModel());

		Headlight audiH = FactoryGetter.getFactory("audi").makeHeadlight();
		Headlight mercH = FactoryGetter.getFactory("mercedes").makeHeadlight();
		System.out.println(audiH.getModel());
		System.out.println(mercH.getModel());
	}

}
