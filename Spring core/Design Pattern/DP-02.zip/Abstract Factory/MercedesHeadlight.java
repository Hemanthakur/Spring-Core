
public class MercedesHeadlight extends Headlight {

	public MercedesHeadlight() {
		super("Mercedes Headlight");
	}

}
