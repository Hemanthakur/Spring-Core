
public abstract class Headlight {

	private final String model;

	public Headlight(String model) {
		this.model = model;
	}

	public String getModel() {
		return model;
	}

}
