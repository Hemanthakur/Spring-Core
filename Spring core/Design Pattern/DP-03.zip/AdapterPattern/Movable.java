package AdapterPattern;

public interface Movable {
	
//	returns speed in MPH 
	public double getSpeed();
	
//	returns price in USD
	public double getPrice();

}
