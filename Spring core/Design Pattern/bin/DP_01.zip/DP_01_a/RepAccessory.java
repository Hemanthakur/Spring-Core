package DP_01_a;

public class RepAccessory implements RepairAccessory {
	public void ProcessAccessoryRepair(String accessoryType) {
		System.out.println(accessoryType +" repair accepted!");

	}
}
