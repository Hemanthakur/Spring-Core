package DP_01_a;

public interface RepairAccessory {
	 void ProcessAccessoryRepair(String accessoryType);
}
