package DP_01_a;

public interface Repair  {
	
    void ProcessPhoneRepair(String modelName);

   
}
