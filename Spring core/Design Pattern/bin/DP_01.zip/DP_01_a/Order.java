package DP_01_a;


public interface Order  {
	void ProcessOrder(String modelName);
}
