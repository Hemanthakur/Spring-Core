package DP_01_a;

public class Rep implements Repair {
	@Override
	public void ProcessPhoneRepair(String modelName) {		
		System.out.println(modelName+" repair accepted!");
	}

	
}