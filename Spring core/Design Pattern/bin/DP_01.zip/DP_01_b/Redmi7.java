package DP_01_b;

public class Redmi7 implements Iphone {
	public String GetPhonePart1() {
		return "Display";
	}
	@Override
	public double GetPart1Cost() {
		return 500;
	}
}
