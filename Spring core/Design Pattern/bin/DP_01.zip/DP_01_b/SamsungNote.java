package DP_01_b;

public class SamsungNote implements Iphone {
	
	public String GetPhonePart1() {
		return "Display";
	}	
	public double GetPart1Cost() {
		return 500;
	}
}
