package DP_01_b;

public interface Iphone {
	public String GetPhonePart1();
	public double GetPart1Cost();
}
